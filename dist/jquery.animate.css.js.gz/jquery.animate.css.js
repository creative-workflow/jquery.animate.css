/*! jquery.animate.css v1.0.2 | MIT */

(function(){jQuery.fn.extend({animateCss:function(n,t,e){return this.each(function(){var a,i,s;return s=t/1e3,i=(s+"s").replace(",","."),(a=$(this)).css("animation-duration",i).addClass("animate "+n),setTimeout(function(){if(a.removeClass("animate "+n),e)return e(a)},t)})}})}).call(this);