/*! jquery.animatecss v1.0.0 | MIT */

(function(){jQuery.fn.extend({animateCss:function(n,t,a){return this.each(function(){var e;if(e=t/1e3,$(this).removeClass(n).css("animation-duration",e+"s").addClass("animate "+n),a)return setTimeout(a,t)})}})}).call(this);